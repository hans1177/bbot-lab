# -*- coding: utf-8 -*-
# PORTABLE_TARGETED_REDEVELOPMENT_V1
# Failure-related bounded prior-signal confirmation only.
import sys,types,numpy as np
_SRC='# -*- coding: utf-8 -*-\n# PORTABLE_GENERATED_SINGLE_V2\n# Exact standalone research source; no local absolute-path dependency.\n# -*- coding: utf-8 -*-\nimport numpy as np\nimport pandas as pd\n\nSTRATEGY_META = {\'name\': \'V3_ADAPTIVE_CHANNEL\', \'development_mode\': \'AUTO_DISCOVERY\', \'data_mode\': \'OHLCV\', \'description\': \'ATR-normalized adaptive trend channel breakout\', \'allowed_timeframes\': [\'1H\', \'6H\', \'12H\', \'1D\', \'1W\']}\n\ndef _num(s):\n    return pd.to_numeric(s, errors="coerce")\n\ndef _signal_dict(v, reason):\n    if int(v)>0: return {"signal":"long","state":"long","strength_long":1.0,"strength_short":0.0,"reason":reason}\n    if int(v)<0: return {"signal":"short","state":"short","strength_long":0.0,"strength_short":1.0,"reason":reason}\n    return {"signal":"wait","state":"wait","strength_long":0.0,"strength_short":0.0,"reason":reason}\n\ndef signal(df, params=None):\n    arr=generate_signals(df.copy(), "LIVE")\n    return _signal_dict(arr[-1] if len(arr) else 0, STRATEGY_META["name"])\n\ndef generate_signals(df, tf):\n    d=df.copy(); c=_num(d["close"]); h=_num(d["high"]); l=_num(d["low"]); pc=c.shift(1); tr=pd.concat([(h-l).abs(),(h-pc).abs(),(l-pc).abs()],axis=1).max(axis=1); atr=tr.ewm(span=20,adjust=False).mean(); ema=c.ewm(span=32,adjust=False).mean(); slope=ema-ema.shift(6); upper=ema+1.2*atr; lower=ema-1.2*atr\n    out=np.zeros(len(d),dtype=np.int8); out[((c>upper)&(slope>0)).fillna(False).to_numpy()]=1; out[((c<lower)&(slope<0)).fillna(False).to_numpy()]=-1; return out\n\nSTRATEGY_META=dict(STRATEGY_META)\nSTRATEGY_META[\'name\']=\'V3_ADAPTIVE_CHANNEL_12H_BROAD_V1\'\nSTRATEGY_META[\'allowed_timeframes\']=[\'12H\']\n'
_mod=types.ModuleType("_bbot_redev_parent")
_mod.__file__="<embedded:redev_parent>"
sys.modules[_mod.__name__]=_mod
exec(compile(_SRC,_mod.__file__,"exec"),_mod.__dict__)
STRATEGY_META=dict(getattr(_mod,"STRATEGY_META",{}))
STRATEGY_META["name"]='V3_ADAPTIVE_CHANNEL_RFULL_VALIDATION_1'
STRATEGY_META["redevelopment_gate"]='FULL_VALIDATION'
STRATEGY_META["redevelopment_cycle"]=1
STRATEGY_META["prior_signal_confirmation_bars"]=1
def generate_signals(df,tf):
    raw=np.asarray(_mod.generate_signals(df,tf),dtype=np.int8)
    out=np.zeros(len(raw),dtype=np.int8)
    if len(raw)==0:return out
    ok=(raw!=0)
    for lag in range(1,1+1):
        shifted=np.zeros(len(raw),dtype=np.int8)
        shifted[lag:]=raw[:-lag]
        ok &= (shifted==raw)
    out[ok]=raw[ok]
    return out
def signal(df,params=None):
    z=generate_signals(df,"LIVE")
    v=int(z[-1]) if len(z) else 0
    return {"signal":"long" if v>0 else "short" if v<0 else "wait","state":"long" if v>0 else "short" if v<0 else "wait","strength_long":1.0 if v>0 else 0.0,"strength_short":1.0 if v<0 else 0.0,"reason":STRATEGY_META.get("name","")}
