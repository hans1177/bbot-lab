# -*- coding: utf-8 -*-
# PORTABLE_TARGETED_REDEVELOPMENT_V1
# Failure-related bounded prior-signal confirmation only.
import sys,types,numpy as np
_SRC='# -*- coding: utf-8 -*-\n# PORTABLE_GENERATED_SINGLE_V2\n# Exact standalone research source; no local absolute-path dependency.\n# -*- coding: utf-8 -*-\nimport numpy as np\nimport pandas as pd\n\ndef _num(s): return pd.to_numeric(s,errors="coerce")\ndef _sig(v,name):\n    if int(v)>0:return {"signal":"long","state":"long","strength_long":1.0,"strength_short":0.0,"reason":name}\n    if int(v)<0:return {"signal":"short","state":"short","strength_long":0.0,"strength_short":1.0,"reason":name}\n    return {"signal":"wait","state":"wait","strength_long":0.0,"strength_short":0.0,"reason":name}\ndef signal(df,params=None):\n    a=generate_signals(df.copy(),"LIVE"); return _sig(a[-1] if len(a) else 0,STRATEGY_META["name"])\nSTRATEGY_META={"name":"V3_DIRECTIONAL_ENTROPY","development_mode":"AUTO_DISCOVERY_WAVE2","data_mode":"OHLCV","description":"low direction entropy trend persistence","allowed_timeframes":["1H","6H","12H","1D","1W"]}\n\ndef generate_signals(df,tf):\n    c=_num(df["close"]); r=c.diff(); up=(r>0).astype(float); p=up.rolling(20,min_periods=20).mean().clip(1e-6,1-1e-6); ent=-(p*np.log(p)+(1-p)*np.log(1-p)); mom=c.pct_change(20); out=np.zeros(len(df),dtype=np.int8); out[((ent<0.60)&(mom>0)).fillna(False).to_numpy()]=1; out[((ent<0.60)&(mom<0)).fillna(False).to_numpy()]=-1; return out\n\nSTRATEGY_META=dict(STRATEGY_META)\nSTRATEGY_META[\'name\']=\'V3_DIRECTIONAL_ENTROPY_1D_BROAD_V1\'\nSTRATEGY_META[\'allowed_timeframes\']=[\'1D\']\n'
_mod=types.ModuleType("_bbot_redev_parent")
_mod.__file__="<embedded:redev_parent>"
sys.modules[_mod.__name__]=_mod
exec(compile(_SRC,_mod.__file__,"exec"),_mod.__dict__)
STRATEGY_META=dict(getattr(_mod,"STRATEGY_META",{}))
STRATEGY_META["name"]='V3_DIRECTIONAL_ENTROPY_RENTRY_RISK_1'
STRATEGY_META["redevelopment_gate"]='ENTRY_RISK'
STRATEGY_META["redevelopment_cycle"]=1
STRATEGY_META["prior_signal_confirmation_bars"]=1
def generate_signals(df,tf):
    raw=np.asarray(_mod.generate_signals(df,tf),dtype=np.int8)
    out=np.zeros(len(raw),dtype=np.int8)
    if len(raw)==0:return out
    ok=(raw!=0)
    for lag in range(1,1+1):
        shifted=np.zeros(len(raw),dtype=np.int8)
        shifted[lag:]=raw[:-lag]
        ok &= (shifted==raw)
    out[ok]=raw[ok]
    return out
def signal(df,params=None):
    z=generate_signals(df,"LIVE")
    v=int(z[-1]) if len(z) else 0
    return {"signal":"long" if v>0 else "short" if v<0 else "wait","state":"long" if v>0 else "short" if v<0 else "wait","strength_long":1.0 if v>0 else 0.0,"strength_short":1.0 if v<0 else 0.0,"reason":STRATEGY_META.get("name","")}
