# -*- coding: utf-8 -*-
# 파일명: v3_safe_channel_z_w24_t0p4_1h_broad_v1.py
# PORTABLE_RUNTIME_ARTIFACT_V1
from __future__ import annotations
import json
from typing import Any
import numpy as np
import pandas as pd
def recipe_name(recipe: dict[str, Any]) -> str:
    base = (
        f"V3_SAFE_{recipe['mode']}"
        f"_W{int(recipe['window'])}"
        f"_T{str(recipe['threshold']).replace('.', 'P')}"
    )

    confirm_mode = str(
        recipe.get(
            "confirm_mode"
        )
        or "BASE"
    ).upper()

    if confirm_mode != "BASE":
        return (
            base
            + "_M_"
            + confirm_mode
        )

    return base


def _num(series: pd.Series) -> pd.Series:
    return pd.to_numeric(series, errors="coerce")


def generate_signals_recipe(df: pd.DataFrame, recipe: dict[str, Any]) -> np.ndarray:
    d = df.copy()
    c = _num(d["close"])
    window = int(recipe["window"])
    threshold = float(recipe["threshold"])
    mode = str(recipe["mode"]).upper()

    out = np.zeros(len(d), dtype=np.int8)

    if mode == "TREND_Z":
        ema = c.ewm(
            span=window,
            adjust=False,
        ).mean()

        vol = (
            c.diff()
            .rolling(
                window,
                min_periods=window,
            )
            .std()
            .replace(
                0,
                np.nan,
            )
        )

        z = (
            c
            - ema
        ) / vol

        slope = (
            ema
            - ema.shift(
                max(
                    2,
                    window // 6,
                )
            )
        )

        long_mask = (
            (z > threshold)
            & (slope > 0)
        )

        short_mask = (
            (z < -threshold)
            & (slope < 0)
        )

    elif mode == "CHANNEL_Z":

        mean = (
            c.rolling(
                window,
                min_periods=window,
            ).mean()
        )

        std = (
            c.rolling(
                window,
                min_periods=window,
            )
            .std()
            .replace(
                0,
                np.nan,
            )
        )

        upper = (
            mean
            + threshold
            * std
        )

        lower = (
            mean
            - threshold
            * std
        )

        momentum = (
            c
            - c.shift(
                max(
                    2,
                    window // 8,
                )
            )
        )

        long_mask = (
            (c > upper)
            & (momentum > 0)
        )

        short_mask = (
            (c < lower)
            & (momentum < 0)
        )

    else:
        raise RuntimeError(
            "SAFE_GRAMMAR_MODE_INVALID"
        )

    confirm_mode = str(
        recipe.get(
            "confirm_mode"
        )
        or "BASE"
    ).upper()

    if confirm_mode == "BASE":
        pass

    elif (
        confirm_mode
        == "PRICE_DIRECTION"
    ):

        # Structural mutation:
        # signal condition + current closed-bar price direction confirmation.
        long_mask = (
            long_mask
            & (
                c
                > c.shift(1)
            )
        )

        short_mask = (
            short_mask
            & (
                c
                < c.shift(1)
            )
        )

    elif (
        confirm_mode
        == "PERSIST_2"
    ):

        # Structural mutation:
        # same bounded entry condition must persist for two closed bars.
        prior_long = (
            long_mask
            .shift(1)
            .fillna(False)
        )

        prior_short = (
            short_mask
            .shift(1)
            .fillna(False)
        )

        long_mask = (
            long_mask
            & prior_long
        )

        short_mask = (
            short_mask
            & prior_short
        )

    else:
        raise RuntimeError(
            "SAFE_GRAMMAR_CONFIRM_MODE_INVALID"
        )

    out[
        long_mask
        .fillna(False)
        .to_numpy()
    ] = 1

    out[
        short_mask
        .fillna(False)
        .to_numpy()
    ] = -1

    return out


def signal_recipe(df: pd.DataFrame, recipe: dict[str, Any]) -> dict[str, Any]:
    arr = generate_signals_recipe(df, recipe)
    value = int(arr[-1]) if len(arr) else 0
    name = recipe_name(recipe)
    if value > 0:
        return {"signal": "long", "state": "long", "strength_long": 1.0, "strength_short": 0.0, "reason": name}
    if value < 0:
        return {"signal": "short", "state": "short", "strength_long": 0.0, "strength_short": 1.0, "reason": name}
    return {"signal": "wait", "state": "wait", "strength_long": 0.0, "strength_short": 0.0, "reason": name}

_RECIPE = json.loads('{"confirm_mode": "BASE", "mode": "CHANNEL_Z", "threshold": 0.4, "window": 24}')
STRATEGY_META = {'name': 'V3_SAFE_CHANNEL_Z_W24_T0P4_1H_BROAD_V1', 'development_mode': 'AUTO_SAFE_GRAMMAR', 'data_mode': 'OHLCV', 'allowed_timeframes': ['1H']}
def generate_signals(df, tf):
    return generate_signals_recipe(df, _RECIPE)
def signal(df, params=None):
    return signal_recipe(df, _RECIPE)
